export const formularioBuscar = document.querySelector('#formulario-buscar'),
            divBuscar = document.querySelector('#buscar'),
            divMensajes = document.querySelector('#mensajes'),
            divResultado = document.querySelector('#resultado'),
            headingResultado = document.querySelector('.letra-resultado h2');